#ifndef _TIM_H
#define _TIM_H
#include "stm32f4xx.h"

#define PWM_PRESCALER		83										// Ԥ��Ƶֵ
#define PWM_CK_CNT			84000000/(PWM_PRESCALER + 1)

extern u32 TIME_Counter;
extern u8  UsartSendFlag;

void TIM3_init(u16 TicPeriod);
void TIM5_init(u16 TicPeriod);
void PWM_TIM_Configuration(void);
void CNT_TIM_Configuration(void);

#endif
