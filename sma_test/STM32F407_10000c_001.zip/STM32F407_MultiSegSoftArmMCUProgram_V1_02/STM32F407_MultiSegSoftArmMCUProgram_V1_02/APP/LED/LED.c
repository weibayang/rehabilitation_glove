#include "LED.h"

// LED GPIO ��ʼ��
void LED_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOF, ENABLE);
	
	GPIO_InitStructure.GPIO_Pin 		= GPIO_Pin_9 | GPIO_Pin_10;
	GPIO_InitStructure.GPIO_Mode 		= GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_Speed 	= GPIO_Speed_100MHz;
	GPIO_InitStructure.GPIO_OType 	= GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd 		= GPIO_PuPd_UP;
	
	GPIO_Init(GPIOF, &GPIO_InitStructure);
}

// LED����
void LED_Light(u8 c)
{
	switch(c)
	{
		case 1:
		{
			GPIO_ResetBits(GPIOF, GPIO_Pin_9);
			break;
		}
		case 2:
		{
			GPIO_ResetBits(GPIOF, GPIO_Pin_10);
			break;
		}
	}
}

// LEDϨ��
void LED_Dark(u8 c)
{
	switch(c)
	{
		case 1:
		{
			GPIO_SetBits(GPIOF, GPIO_Pin_9);
			break;
		}
		case 2:
		{
			GPIO_SetBits(GPIOF, GPIO_Pin_10);
			break;
		}
	}
}

// LED����ת������
void LED_Spark(u8 c)
{
	switch(c)
	{
		case 1:
		{
			GPIO_ToggleBits(GPIOF, GPIO_Pin_9);
			break;
		}
		case 2:
		{
			GPIO_ToggleBits(GPIOF, GPIO_Pin_10);
			break;
		}
	}
}