#ifndef _GMValueDef_H
#define _GMValueDef_H
#include "stm32F4xx.h"

#endif
