#ifndef __StepMotor_H
#define __StepMotor_H
#include "stm32f4xx.h"
#include "TIM.h"

#define GPIO_StepMotor 				GPIOB
#define RCC_GPIO_StepMotor 		RCC_AHB1Periph_GPIOB
#define ENA_Pin								GPIO_Pin_0
#define DIR_Pin								GPIO_Pin_1

#define SM_ENABLE							0
#define SM_DISABLE						1
#define PulsePerCircle				20000

void ENA_DIR_Init(void);
void PWM_Output(u32 Frequency, u32 Dutycycle, u32 NumPulse);
void StepMotorCMD(u8 State);
void StepMotorRun(float AngleSpeed, float Angle, u8 Direction);
void StepMotorStop(void);
#endif
